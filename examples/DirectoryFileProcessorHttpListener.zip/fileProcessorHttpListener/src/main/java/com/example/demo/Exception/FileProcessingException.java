package com.example.demo.Exception;

public class FileProcessingException extends RuntimeException{
	public FileProcessingException(String message) {
		super(message);
	}
}
