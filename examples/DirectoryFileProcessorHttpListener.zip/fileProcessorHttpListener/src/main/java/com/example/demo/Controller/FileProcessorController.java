package com.example.demo.Controller;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Exception.FileProcessingException;
import com.example.demo.Service.FileProcessingService;

@RestController
@RequestMapping("/api/files")
public class FileProcessorController {
	
	@Autowired
	private FileProcessingService fileProcessingService;
	
	//Reading single file
//	@PostMapping("/process")
//	public ResponseEntity<String> processFile(@RequestParam String filePath){
//		System.out.println("FilePath : "+filePath);
//		File file = new File(filePath);
//		System.out.println("File : "+file);
//		
//		if (!file.exists()) return ResponseEntity.badRequest().body("File not found");
//		
//		boolean status = fileProcessingService.routeFile(file);
//		return ResponseEntity.ok("File processed: " + (status ? "Success" : "Failure"));
//	}
	
	
	//Reading a directory
	@PostMapping("/process")
	public ResponseEntity<String> processFile(@RequestParam String directoryPath){
		//System.out.println("Received path: " + directoryPath);
		File directory = new File(directoryPath);
		//System.out.println("Absolute path: " + directory.getAbsolutePath());
		//System.out.println("Exists: " + directory.exists());
		//System.out.println("Is Directory: " + directory.isDirectory());
		
		// Just return these values to confirm
	    if (!directory.exists()) {
	        return ResponseEntity.badRequest().body("Path doesn't exist.");
	    }
	    if (!directory.isDirectory()) {
	        return ResponseEntity.badRequest().body("Path is not a directory.");
	    }
		
		File[] files = directory.listFiles();
		if(files == null || files.length==0) {
			throw new FileProcessingException("No files found in the directory.");
		}
		
		StringBuilder resultSummary = new StringBuilder("File Processing Summary:\n");
		
		for(File file : files) {
			if(file.isFile()) {	
				try {
					boolean status = fileProcessingService.routeFile(file);
					resultSummary.append(file.getName())
					.append(" -> ")
					.append(status ? "Success" : "Failure")
					.append("\n");
				}catch(Exception e) {
					resultSummary.append(file.getName())
					.append(" -> Exception: ")
					.append(e.getMessage())
					.append("\n");
				}
			}
		}
		
		
		return ResponseEntity.ok(resultSummary.toString());
	}
}
