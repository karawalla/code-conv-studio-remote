package com.example.demo.Service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class InventoryFileService {
	
//	public boolean process(File file) {
//        try {
//            // Create Processed directory if it doesn't exist
//            File processedDir = new File("C:/Users/Pradeep/Desktop/Repo/Spring File Operation/SampleOutputFiles/Processed");
//            if (!processedDir.exists()) {
//                processedDir.mkdirs();
//            }
//
//            // Destination file inside Processed folder
//            File processedFile = new File(processedDir, "processed_" + file.getName());
//
//            try (BufferedReader reader = new BufferedReader(new FileReader(file));
//                 BufferedWriter writer = new BufferedWriter(new FileWriter(processedFile))) {
//
//                String line;
//                while ((line = reader.readLine()) != null) {
//                    writer.write(line + " - INVENTORY PROCESSED");
//                    writer.newLine();
//                }
//            }
//
//            return true;
//
//        } catch (IOException e) {
//            e.printStackTrace();
//            return false;
//        }
//    }
	
	
public boolean process(File file) {
	
	System.out.println("Inventory File Name : "+file.getName());
		
        try (BufferedReader reader = new BufferedReader(new FileReader(file));
             BufferedWriter writer = new BufferedWriter(new FileWriter("C:/Users/Pradeep/Desktop/Repo/Spring File Operation/SampleOutputFiles/processed_" + file.getName()))) {

            String line;
            while ((line = reader.readLine()) != null) {
                writer.write(line + " - INVENTORY PROCESSED");
                writer.newLine();
            }
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.TEXT_PLAIN);
            
            HttpEntity<String> entity = new HttpEntity<>(file.getName(), headers);
            
            RestTemplate restTemplate = new RestTemplate();
            System.out.println("Hello");
            
        	Boolean result = restTemplate.postForObject("http://localhost:8087/api/inventories/inventory", entity, Boolean.class);
        	System.out.println(result);
            return result;

        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
}
